/* eslint-disable */
export default {
  displayName: 'policy-payments-gateway',
  preset: '../../jest.preset.js',
  testEnvironment: 'node',
  transform: {
    '^.+\\.[tj]s$': ['ts-jest', { tsconfig: '<rootDir>/tsconfig.spec.json' }],
  },
  moduleFileExtensions: ['ts', 'js', 'html'],
  coverageDirectory: '../../coverage/apps/policy-payments-gateway',
  setupFilesAfterEnv: ['<rootDir>/setup-test-env.ts'],
  collectCoverageFrom: [
    './src/**/*.ts',
    '!../src/__mocks__/**',
    '!./src/environments/**',
    '!./src/main.ts',
  ],
  coverageReporters: [
    'clover',
    'json',
    'lcov',
    'text',
  ],
  coverageThreshold: {
    global: {
      branches: 90,
      functions: 90,
      lines: 90,
    },
  },
};
