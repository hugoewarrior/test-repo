import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
//import { FastifyLoaderModule } from 'nestjs-fastify-loader';
import { MercuriusGatewayDriver, MercuriusGatewayDriverConfig } from '@nestjs/mercurius';
import { plugins } from './plugins';
import { LoggerModule } from 'nestjs-pino/LoggerModule';

@Module({
  imports: [
    LoggerModule.forRoot(),
    GraphQLModule.forRoot<MercuriusGatewayDriverConfig>({
      driver: MercuriusGatewayDriver,
      gateway: {
        services: [
          {
            name: 'policy-information-subgraph',
            url: `https://countries.trevorblades.com/graphql`,
          },
        ],
      },
      autoSchemaFile: true,
    }),
    //FastifyLoaderModule.forRoot(plugins),
  ],
})
export class AppModule { }
