import fp from 'fastify-plugin';
import mercuriusAuth from 'mercurius-auth';
import { Authorization, AuthorizationResponse } from '@nassa/authorization';

export default fp(
  async (fastify) => {
    fastify.register(mercuriusAuth, {
      authContext(context) {
        return {
          token: String(context.reply.request.headers['authorization']),
          refreshToken:
            String(context.reply.request.headers['x-nassa-current-refresh-token']),
        };
      },
      async applyPolicy(authDirectiveAST, parent, args, context) {
        context.app.log.info(`applyPolicy token: ${context.auth.token}`);
        context.app.log.info(
          `applyPolicy refreshToken: ${context.auth.refreshToken}`
        );
        const authentication = new Authorization({
          url: process.env.AUTH_URL as string,
          clientId: process.env.HEALTH_AUTH_CLIENT_SECRET as string,
          clientSecret: process.env.HEALTH_AUTH_CLIENT_SECRET as string,
          applicationKey: process.env.APPLICATION_KEY as string,
        });
        const authorization: AuthorizationResponse =
          await authentication.Authorize(
            context.auth.token,
            context.auth.refreshToken
          );
        context.reply.header('Access-Control-Expose-Headers', '*');
        context.reply.header('X-NASSA-REFRESH-JWT', authorization.token);
        context.reply.header(
          'X-NASSA-REFRESH-TOKEN',
          authorization.refreshToken
        );

        if (!authorization.authorize) {
          throw new Error('Unauthorized User');
        }

        return authorization.authorize;
      },
      authDirective: 'auth',
    });
  },
  {
    dependencies: ['mercurius'],
  }
);
