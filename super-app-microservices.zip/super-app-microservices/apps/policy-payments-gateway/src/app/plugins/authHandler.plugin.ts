import fp from 'fastify-plugin';
import fastifyAuth from '@fastify/auth';

export default fp(async (fastify) => {
  void fastify.register(fastifyAuth);
});