import authorizationPlugin from './authorization.plugin';
import proxyPlugin from './proxy.plugin';
import authHandlerPlugin from './authHandler.plugin';
import policyPlugin from './policy.plugin';

const plugins = [];
plugins.push(authorizationPlugin);
plugins.push(proxyPlugin);
plugins.push(authHandlerPlugin);
plugins.push(policyPlugin);

export { plugins };
