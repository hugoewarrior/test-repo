import fp from 'fastify-plugin';
import { FastifyReply, FastifyRequest } from 'fastify';
import { Authorization } from '@nassa/authorization';
//import { UnauthorizedUserError } from '@gateway/shared';

export default fp(async (fastify) => {
  void fastify
    .decorate(
      'verifyToken',
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      async (request: FastifyRequest, reply: FastifyReply, done: any) => {
        if (request.url !== '/graphql') {
          const authentication = new Authorization({
            url: process.env.AUTH_URL as string,
            clientId: process.env.HEALTH_AUTH_CLIENT_SECRET as string,
            clientSecret: process.env.HEALTH_AUTH_CLIENT_SECRET as string,
            applicationKey: process.env.APPLICATION_KEY as string,
          });
          const { authorize } = await authentication.Authorize(
            request.headers.authorization as string,
            ''
          );

          if (!authorize) {
            request.log.warn(`Unauthorized request`);
            void reply.code(401).send({ error: 'Unauthorized' });
            done(new Error('Unauthorized User'));
          }
        }
      }
    )
    .addHook('preHandler', fastify.auth([fastify.verifyToken]));
});

declare module 'fastify' {
  export interface FastifyInstance {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    verifyToken: any;
  }
}
