import fp from 'fastify-plugin';
import proxy from '@fastify/http-proxy';

export default fp(async (fastify) => {
  void fastify.register(proxy, {
    upstream: process.env.POLICY_INFORMATION_URL as string,
    prefix: '/policy-information-subgraph/api',
    proxyPayloads: false,
  });
});
