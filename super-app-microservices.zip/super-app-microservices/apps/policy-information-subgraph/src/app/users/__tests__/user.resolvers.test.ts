import { Test } from '@nestjs/testing';
import { mockUserService, mockFindByIdSuccess } from 'nassa/nestjs-testing';

import { UsersResolvers } from '../user.resolvers';
import { UsersService } from '../user.service';

/**
 * Initialize tools and Mocks
 */

let resolvers: UsersResolvers;
const requiredPropertyNames = ["id", "name"];
const ID = "5";

beforeAll(async () => {
    /**
     * Initialize @UsersResolvers Testing module
     */
    const app = await Test.createTestingModule({
        controllers: [UsersResolvers],
        providers: [{ provide: UsersService, useValue: mockUserService }],
    }).compile();

    resolvers = app.get<UsersResolvers>(UsersResolvers);
});


/**
 * Tests
 */

describe('UsersResolvers functions behavoir on success scenarios', () => {
    it('When given a valid value, it should return object', async () => {
        //Require Properties for the Response

        const resp = await resolvers.getUser(ID);
        expect(resp).toEqual(mockFindByIdSuccess(ID));
        //Test that the response contains all @requiredPropertyNames
        requiredPropertyNames.forEach((n) => {
            expect(resp).toHaveProperty(n)
        })
    });

    it('', async () => {
        //Require Properties for the Response
        const resp = await resolvers.resolveReference({ __typename: "typename", id: "8" });
        expect(resp).toEqual(mockFindByIdSuccess("8"));
        //Test that the response contains all @requiredPropertyNames
        requiredPropertyNames.forEach((n) => {
            expect(resp).toHaveProperty(n)
        })
    });

});

