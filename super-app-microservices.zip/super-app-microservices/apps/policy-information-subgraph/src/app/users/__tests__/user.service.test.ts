import { Test } from '@nestjs/testing';
import { mockFindByIdSuccess } from 'nassa/nestjs-testing';

import { UsersService } from '../user.service';

/**
 * Initialize tools and Mocks
 */

let service: UsersService;
const requiredPropertyNames = ["id", "name"];
const ID = "5"

beforeAll(async () => {
    /**
     * Initialize @UsersService Testing module
     */
    const app = await Test.createTestingModule({
        providers: [UsersService],
    }).compile();

    service = app.get<UsersService>(UsersService);
});


describe('UsersService functions behavoir on success scenarios', () => {
    it('When given a valid value, it should return object"', async () => {
        //Require Properties for the Response
        const resp = await service.findById(ID);
        expect(resp).toEqual(mockFindByIdSuccess(ID));
        //Test that the response contains all @requiredPropertyNames
        requiredPropertyNames.forEach((n) => {
            expect(resp).toHaveProperty(n)
        })

    });


});

