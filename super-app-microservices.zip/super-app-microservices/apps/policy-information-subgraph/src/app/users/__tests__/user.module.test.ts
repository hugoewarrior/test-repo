import { Test } from '@nestjs/testing';

import { UsersModule } from '../user.module';
import { UsersResolvers } from '../user.resolvers';
import { UsersService } from '../user.service';

/**
 * Initialize tools and Mocks
 */

let userResolver: UsersResolvers
let userService: UsersService

beforeAll(async () => {
    /**
     * Initialize @UsersModule Testing module
     */
    const app = await Test.createTestingModule({
        imports: [UsersModule],
    }).compile();

    userResolver = app.get(UsersResolvers);
    userService = app.get(UsersService);

});


/**
 * Tests
 */

describe('Module initialization should cotain all necessary', () => {
    it('Should contains Resolvers and Service', async () => {
        expect(userResolver).toBeInstanceOf(UsersResolvers);
        expect(userService).toBeInstanceOf(UsersService);
    });
});

