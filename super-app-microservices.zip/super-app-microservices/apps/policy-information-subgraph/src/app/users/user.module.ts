import { Module } from '@nestjs/common';
import { UsersResolvers } from './user.resolvers';
import { UsersService } from './user.service';

@Module({
  providers: [UsersResolvers, UsersService],
})
export class UsersModule {}
