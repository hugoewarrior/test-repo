import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import {
  MercuriusFederationDriver,
  MercuriusFederationDriverConfig,
} from '@nestjs/mercurius';
import { UsersModule } from './users/user.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { join } from 'path';
import { LoggerModule } from 'nestjs-pino/LoggerModule';

@Module({
  imports: [
    LoggerModule.forRoot(),
    GraphQLModule.forRoot<MercuriusFederationDriverConfig>({
      driver: MercuriusFederationDriver,
      typePaths: [join(__dirname, '**/*.graphql')],
    }),
    UsersModule,    
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}