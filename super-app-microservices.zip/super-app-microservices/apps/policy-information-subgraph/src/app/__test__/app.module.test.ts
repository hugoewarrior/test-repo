import { Test } from '@nestjs/testing';
import {
    FastifyAdapter,
    NestFastifyApplication,
} from '@nestjs/platform-fastify';
import { AppModule } from '../app.module';
import { AppController } from '../app.controller';
import { AppService } from '../app.service';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';

/**
 * Initialize tools and Mocks
 */

let appController: AppController

let subraph: INestApplication;

const mockService = { getData: () => ({ message: 'Hello API Mock' }) };

beforeEach(() => {
    jest.resetModules();
});

beforeAll(async () => {
    /**
     * Initialize @AppModule Testing module
     */
    const app = await Test.createTestingModule({
        imports: [AppModule],
    }).overrideProvider(AppService).useValue(mockService).compile();

    subraph = app.createNestApplication<NestFastifyApplication>(new FastifyAdapter())

    appController = await app.resolve(AppController);

    await subraph.init();
    await subraph.listen(5001);

});

afterAll(async () => {
    await subraph.close();
});

/**
 * Tests
 */

describe('Module initialization should contain all necessary', () => {
    it('Should contains Instance of controller', async () => {
        expect(appController).toBeInstanceOf(AppController);
    });

    it('/GET/data', async () => {
        return request(subraph.getHttpServer())
            .get('/')
            .expect(200)
            .expect(mockService.getData())
    });
});

