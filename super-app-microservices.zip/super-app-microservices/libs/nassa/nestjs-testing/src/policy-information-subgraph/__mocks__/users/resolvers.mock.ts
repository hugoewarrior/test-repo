/**
 * Mock Values for resolvers on policy-information-subgraph
 */
export const mockUserService = {
    findById: (e: string) => (
        {
            id: e,
            name: 'GraphQL',
        })
}