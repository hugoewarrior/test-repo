/**
 * Mock Values for services on policy-information-subgraph
 */

export const mockFindByIdSuccess = (id: string) => ({
    id,
    name: 'GraphQL',
})